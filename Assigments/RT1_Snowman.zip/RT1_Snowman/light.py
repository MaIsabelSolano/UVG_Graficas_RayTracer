class Light(object):
    def __init__(self, position, intensity):
        self.position = position
        self.intensity = intensity