class Material:
    def __init__(self, diffuse):
        self.diffuse = diffuse